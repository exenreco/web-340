"use strict";

/**
 * Author:        Exenreco Bell
 * Date:          October 30, 2024
 * File Name:     failing-script.js
 * Description:   An error message for failed scripts
 */

// TODO: Implement this script
console.error("This is an error message");